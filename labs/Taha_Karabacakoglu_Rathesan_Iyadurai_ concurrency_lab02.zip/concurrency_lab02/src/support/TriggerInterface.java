/*
  File: TriggerInterface.java
*/

package support;

public interface TriggerInterface
{

    public void performAction() throws InterruptedException;

}
