
package bridge;

/** This bridge should be safe and fair 
 */
public class FairBridge extends DefaultBridge {
	private boolean bridgeInUse = false;
	
	private int blueTurns = 0;
	private int redTurns = 0;
	
	private String currentPriority = "";
	
	/** a red car wants to enter the bridge
	 */
	public void redEnter() throws InterruptedException {
		enterBridge("red");
	}; 
	
	/** a red car exits from the bridge
	 */
	public void redExit() {
		exitBridge("red");
	}; 
	
	/** a blue car wants to enter the bridge
	 */
	public void blueEnter() throws InterruptedException {
		enterBridge("blue");
	}; 
	
	/** a blue car exits from the bridge
	 */
	public void blueExit() {
		exitBridge("blue");
	}; 
	
	private synchronized void enterBridge(String color) throws InterruptedException {
		while (bridgeInUse || otherPrioritized(color)) {
			wait();
		}

		bridgeInUse = true;
	}

	private boolean otherPrioritized(String color) {
		if (color.equals("red")) {
			return isPrioritized("blue");
		} else {
			return isPrioritized("red");
		}
	}

	private void incCounter(String color) {
		if (color.equals("red")) {
			redTurns++;
		} else {
			blueTurns++;
		}
		
		System.out.println("Blue turns: " + blueTurns);
		System.out.println("Red turns: " + redTurns);
	}

	private synchronized void exitBridge(String color) {
		incCounter(color);
		
		if (redTurns > blueTurns) {
			currentPriority = "blue";
		} else if (redTurns < blueTurns) {
			currentPriority = "red";
		} else {
			currentPriority = "";
		}
		
		bridgeInUse = false;
		notifyAll();
	}
	
	private boolean isPrioritized(String color) {		
		return currentPriority.equals(color);
	}
}
