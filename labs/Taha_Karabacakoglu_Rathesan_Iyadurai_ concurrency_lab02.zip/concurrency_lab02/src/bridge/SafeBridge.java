

package bridge;

/** This bridge should be safe... 
 */
public class SafeBridge extends DefaultBridge {
	private boolean bridgeInUse = false;
	
	/** a red car wants to enter the bridge
	 */
	public void redEnter() throws InterruptedException {
		enterBridge();
	}; 
	
	/** a red car exits from the bridge
	 */
	public void redExit() {
		exitBridge();
	}; 
	
	/** a blue car wants to enter the bridge
	 */
	public void blueEnter() throws InterruptedException {
		enterBridge();
	}; 
	
	/** a blue car exits from the bridge
	 */
	public void blueExit() {
		exitBridge();
	}; 
	
	private synchronized void enterBridge() throws InterruptedException {
		while (bridgeInUse) {
			wait();
		}

		bridgeInUse = true;
	}

	private synchronized void exitBridge() {
		bridgeInUse = false;
		notifyAll();
	}
}
