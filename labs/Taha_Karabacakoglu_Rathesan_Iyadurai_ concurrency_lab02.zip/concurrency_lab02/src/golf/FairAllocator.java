/**
 * FairAllocator Class
 *
 * First-come, first-serve using tickets.
 */
package golf;

// To be implemented ...
public class FairAllocator extends SimpleAllocator {
	public FairAllocator(int n) {
		super(n);
	}
	
	synchronized public void get(int n) throws InterruptedException {
		while ( n > available ) {
			wait();
		}
		available -= n;
	}

	synchronized public void put(int n) {
		available += n;
		notifyAll();
	}
}
