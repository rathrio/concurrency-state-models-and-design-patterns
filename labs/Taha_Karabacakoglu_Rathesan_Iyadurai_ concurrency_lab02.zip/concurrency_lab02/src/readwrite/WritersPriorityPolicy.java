/*
 File: WritersPriorityReadWrite.java
 */

package readwrite;

//To be implemented ...
public class WritersPriorityPolicy extends SafeReadWritePolicy {
	boolean writerWaiting = false;
	
	public WritersPriorityPolicy(ReaderWriterPanel view) {
		super(view);
	}
	
	public synchronized void acquireRead() throws InterruptedException {
		while ( writing && writerWaiting ) {
			wait();
		}
		readers++;
		view.setReader( readers );
	}
	
	public synchronized void acquireWrite() throws InterruptedException {
		while ( readers > 0 || writing ) {
			writerWaiting = true;
			wait();
		}
		writerWaiting = false;
		writing = true;
		view.setWriter();
	}
}
