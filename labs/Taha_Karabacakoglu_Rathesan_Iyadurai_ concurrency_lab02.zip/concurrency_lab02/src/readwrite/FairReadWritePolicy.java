/*
 File: FairReadWrite.java
 */

package readwrite;

//To be implemented ...
public class FairReadWritePolicy extends WritersPriorityPolicy {
	
	private boolean writersHavePriority = false;
	
	public FairReadWritePolicy(ReaderWriterPanel view) {
		super(view);
	}
	
	public synchronized void acquireRead() throws InterruptedException {
		while ( writing && writerWaiting ) {
			wait();
		}
		readers++;
		view.setReader( readers );
	}
	
	public synchronized void acquireWrite() throws InterruptedException {
		while ( readers > 0 || writing ) {
			if (writersHavePriority) {
				writerWaiting = true;
				writersHavePriority = false;
			} else {
				writersHavePriority = true;
			}

			wait();
		}
		writerWaiting = false;
		writing = true;
		view.setWriter();
	}
}
